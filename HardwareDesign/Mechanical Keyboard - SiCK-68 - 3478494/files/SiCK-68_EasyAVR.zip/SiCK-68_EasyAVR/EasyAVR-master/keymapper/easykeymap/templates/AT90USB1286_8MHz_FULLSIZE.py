# This file is auto-generated.  Do not edit.

hex_file_name = 'AT90USB1286_8MHz_FULLSIZE.hex'
device = 'AT90USB1286'
speed = '8MHz'
size = 'FULLSIZE'
simple = False

layers_map = 0x00000ca5
actions_map = 0x0000077d
tapkeys_map = 0x00000255
macro_map = 0x000011cd
led_layers_map = 0x00000250
num_leds_map = 0x0000333b
num_ind_map = 0x0000333a
led_hw_map = 0x0000330a
led_map = 0x000032de
num_bl_enab_map = 0x000032dd
bl_mask_map = 0x000032cd
bl_mode_map = 0x000031cd
strobe_cols_map = 0x000033fb
strobe_low_map = 0x000033fa
num_strobe_map = 0x000033f9
num_sense_map = 0x000033f8
matrix_init_map = 0x000033ec
matrix_strobe_map = 0x00003368
matrix_sense_map = 0x0000333c
kmac_key_map = None
boot_ptr_map = 0x000037c7
prod_str_map = 0x00003811
endpoint_opt_map = 0x000039b3
conf_desc_map = 0x00003861
