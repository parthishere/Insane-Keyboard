#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
#
# Easy AVR USB Keyboard Firmware Keymapper
# Copyright (C) 2018 David Howland
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.

"""Constants and functions for sizing the interface elements to the screen."""

import wx


# XXX TODO implement scaling for high DPI displays, perhaps with GetTextExtent

UNIT_SIZE = 12
GRID_SIZE = wx.Size(UNIT_SIZE, UNIT_SIZE)

MARGIN = 4

MIN_STATUS_WIDTH = 75

WIZ_WIDTH = 400
