
Developer's Guide
=================

This section provides background information developers looking to modify the 
C code of the firmware or the Python code of the keymapper application.  
Typical users do not need to read the documents in this section.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   firmware
   keymapper
