#!/bin/sh

cd "$( dirname "$0" )/keymapper"
python3 -m easykeymap
